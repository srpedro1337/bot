
// clovermods



function menu(prefix, nomeBot, pushname) {

return `
╭─⊣〘 ${nomeBot} 〙
║
╠🐞➽𝐔𝐙𝐔𝐀𝐑𝐈𝐎: ${pushname}
╠🐞➽𝐕𝐄𝐑𝐒Ã𝐎: 2.0.0
╠🐞➽𝐍𝐎𝐌𝐄:${pushname}
║
║╭─⊣〘 MENUS 〙
║
╠🐞➽${prefix}Menuadm
╠🐞➽${prefix}Menudono
╠🐞➽${prefix}Menuanime
║
║╭─⊣〘 DOWNLOADER 〙
║
╠🐞➽${prefix}tiktokvd (link)
╠🐞➽${prefix}tiktokad (link)
╠🐞➽${prefix}Play (nome da musica)
╠🐞➽${prefix}Playvideo (nome do video)
║
║╭─⊣〘 ADICIONAIS 〙
║
╠🐞➽${prefix}anagrama
╠🐞➽${prefix}ppt
╠🐞➽${prefix}adivinhação 
╠🐞➽${prefix}alugar
╠🐞➽${prefix}comprabt
╠🐞➽${prefix}convite [link do gp]
╠🐞➽${prefix}ping
╠🐞➽${prefix}metadinha
╠🐞➽${prefix}metadinha2
╠🐞➽${prefix}metadinha3
╠🐞➽${prefix}perfil
╠🐞➽${prefix}google
╠🐞➽${prefix}gerarcpf
╠🐞➽${prefix}encurtalink
╠🐞➽${prefix}ddd
╠🐞➽${prefix}listabr
╠🐞➽${prefix}listafake
╠🐞➽${prefix}bug
╠🐞➽${prefix}avalie
╠🐞➽${prefix}novocmd
║
║╭─⊣〘 MENUS ADM 〙
║
╠🐞➽${prefix}antilink 1/0
╠🐞➽${prefix}Bemvindo 1 / 0
╠🐞➽${prefix}antiaudio 1 / 0
╠🐞➽${prefix}antivideo 1 / 0
╠🐞➽${prefix}tagall (marcar todos) 
╠🐞➽${prefix}marcar (marcar todos) 
╠🐞➽${prefix}Antiimg 1 / 0
╠🐞➽${prefix}antisticker 1/0
╠🐞➽${prefix}autoreação
╠🐞➽${prefix}autofig 1/0
╠🐞➽${prefix}hidetag [marcar todos] 
╠🐞➽${prefix}descgp
╠🐞➽${prefix}nomegp
╠🐞➽${prefix}fotogp
╠🐞➽${prefix}limpar
╠🐞➽${prefix}delete
╠🐞➽${prefix}d
╠🐞➽${prefix}novolink
╠🐞➽${prefix}infogp
╠🐞➽${prefix}status
╠🐞➽${prefix}ban @numero
╠🐞➽${prefix}sairgp
╠🐞➽${prefix}reviver [marcar a msg]
╠🐞➽${prefix}kick @numero
╠🐞➽${prefix}add @numero
╠🐞➽${prefix}linkgp
╠🐞➽${prefix}promover @numero
╠🐞➽${prefix}rebaixar @numero
╠🐞➽${prefix}dellistanegra
╠🐞➽${prefix}addlistanegra
╠🐞➽${prefix}addlista [adiciona na lista de autoban]
╠🐞➽${prefix}dellista [deleta da lista de autoban]
╠🐞➽${prefix}listban
╠🐞➽${prefix}autoban [modo de ban]
╠🐞➽${prefix}kickfake [remove todos fake]
╠🐞➽${prefix}banfake [remove todos fake]
╠🐞➽${prefix}configp
║
║╭─⊣〘 MENU PREMIUM 〙
║
╠🐞➽${prefix}ddd
╠🐞➽${prefix}gerarcpf
╠🐞➽${prefix}clima
╠🐞➽${prefix}premiumlist
║
║╭─⊣〘 BRINCADEIRAS 〙
║
┃🐞➽${prefix}fazernick
┃🐞➽${prefix}Pau
┃🐞➽${prefix}ppt
┃🐞➽${prefix}Gadometro
┃🐞➽${prefix}Chance (Texto)
┃🐞➽${prefix}cassino 
┃🐞➽${prefix}casal
┃🐞➽${prefix}shipo
┃🐞➽${prefix}alma-gemeas
┃🐞➽${prefix}gay
┃🐞➽${prefix}feio
┃🐞➽${prefix}vesgo
┃🐞➽${prefix}bebado
┃🐞➽${prefix}gado
┃🐞➽${prefix}gostoso
┃🐞➽${prefix}gostosa
┃🐞➽${prefix}rankgay
┃🐞➽${prefix}rankgado
┃🐞➽${prefix}rankcorno
║
║╭─⊣〘 FIGURINHAS 〙
║
╠🐞➽${prefix}sticker
╠🐞➽${prefix}roubar [marcar a figu] 
╠🐞➽${prefix}rename [marcar a figu]
╠🐞➽${prefix}sfundo 
║
╚════• 〘${nomeBot}〙•═════╝
`
}

function menuadm(prefix, nomeBot, pushname) {

return `
╭─⊣〘 ${nomeBot} 〙
║
╠🐞➽𝐔𝐙𝐔𝐀𝐑𝐈𝐎: ${pushname}
╠🐞➽𝐕𝐄𝐑𝐒Ã𝐎: 2.0.0
╠🐞➽𝐍𝐎𝐌𝐄:${pushname}
║
║╭─⊣〘 ADMS 〙
║
╠🐞➽${prefix}antilink 1/0
╠🐞➽${prefix}Bemvindo 1 / 0
╠🐞➽${prefix}antiaudio 1 / 0
╠🐞➽${prefix}antivideo 1 / 0
╠🐞➽${prefix}tagall (marcar todos) 
╠🐞➽${prefix}marcar (marcar todos) 
╠🐞➽${prefix}Antiimg 1 / 0
╠🐞➽${prefix}antisticker 1/0
╠🐞➽${prefix}autoreação
╠🐞➽${prefix}autofig 1/0
╠🐞➽${prefix}hidetag [marcar todos] 
╠🐞➽${prefix}descgp
╠🐞➽${prefix}nomegp
╠🐞➽${prefix}fotogp
╠🐞➽${prefix}clear
╠🐞➽${prefix}limpar
╠🐞➽${prefix}delete
╠🐞➽${prefix}d
╠🐞➽${prefix}novolink
╠🐞➽${prefix}infogp
╠🐞➽${prefix}abrirgp
╠🐞➽${prefix}status
╠🐞➽${prefix}fechagp
╠🐞➽${prefix}ban @numero
╠🐞➽${prefix}sairgp
╠🐞➽${prefix}reviver [marcar a msg]
╠🐞➽${prefix}kick @numero
╠🐞➽${prefix}add @numero
╠🐞➽${prefix}linkgp
╠🐞➽${prefix}promover @numero
╠🐞➽${prefix}rebaixar @numero
╠🐞➽${prefix}dellistanegra
╠🐞➽${prefix}addlistanegra
╠🐞➽${prefix}addlista [adiciona na lista de autoban]
╠🐞➽${prefix}dellista [deleta da lista de autoban]
╠🐞➽${prefix}listban
╠🐞➽${prefix}autoban [modo de ban]
╠🐞➽${prefix}kickfake [remove todos fake]
╠🐞➽${prefix}banfake [remove todos fake]
╠🐞➽${prefix}configp
║
╚════• 〘${nomeBot}〙•═════╝
`
}



function menudono(prefix, nomeBot, pushname) {

return `
╭─⊣〘 ${nomeBot} 〙
║
╠🐞➽𝐔𝐙𝐔𝐀𝐑𝐈𝐎: ${pushname}
╠🐞➽𝐕𝐄𝐑𝐒Ã𝐎: 2.0.0
╠🐞➽𝐍𝐎𝐌𝐄:${pushname}
║
║╭─⊣〘 MENUS 〙
║
╠🐞➽${prefix}premiumlist
╠🐞➽${prefix}addpremium @
╠🐞➽${prefix}delpremium @
╠🐞➽${prefix}bangp
╠🐞➽${prefix}transmitir 
╠🐞➽${prefix}unbangp
╠🐞➽${prefix}reviverqr
╠🐞➽${prefix}arquivargp
╠🐞➽${prefix}nuke
╠🐞➽${prefix}entrar [link do gp]
╠🐞➽${prefix}antipv 1
╠🐞➽${prefix}antipv 0
╠🐞➽${prefix}seradm 
╠🐞➽${prefix}sermembro 
╠🐞➽${prefix}listagp 
╠🐞➽${prefix}serpremium
║
╚════• 〘${nomeBot}〙•═════╝
`
}

function menuanime(prefix, nomeBot, pushname) {

return `
╭─⊣〘 ${nomeBot} 〙
║
╠🐞➽𝐔𝐙𝐔𝐀𝐑𝐈𝐎: ${pushname}
╠🐞➽𝐕𝐄𝐑𝐒Ã𝐎: 1.0.0
╠🐞➽𝐍𝐎𝐌𝐄:${pushname}
║
║╭─⊣〘 MENUS 〙
║
╠🐞➽${prefix}cosplay
╠🐞➽${prefix}waifu
╠🐞➽${prefix}waifu2
╠🐞➽${prefix}shota
╠🐞➽${prefix}loli
╠🐞➽${prefix}yotsuba
╠🐞➽${prefix}shinomiya
╠🐞➽${prefix}yumeko
╠🐞➽${prefix}tejina
╠🐞➽${prefix}chiho
╠🐞➽${prefix}shizuka
╠🐞➽${prefix}boruto
╠🐞➽${prefix}kagori
╠🐞➽${prefix}kaga
╠🐞➽${prefix}kotori
╠🐞➽${prefix}mikasa
╠🐞➽${prefix}akiyama
╠🐞➽${prefix}hinata
╠🐞➽${prefix}minato
╠🐞➽${prefix}naruto
╠🐞➽${prefix}nezuko
╠🐞➽${prefix}yuki
╠🐞➽${prefix}hestia
╠🐞➽${prefix}emilia
╠🐞➽${prefix}itachi
╠🐞➽${prefix}madara
╠🐞➽${prefix}sasuke
╠🐞➽${prefix}deidara
╠🐞➽${prefix}sakura
╠🐞➽${prefix}tsunade
┃
┝━〢 🐞 Hentai/+18 no pv
┃
╠🐞➽ ${prefix}ahegao
╠🐞➽ ${prefix}ass
╠🐞➽ ${prefix}bdsm
╠🐞➽ ${prefix}blowjob
╠🐞➽ ${prefix}cuckold
╠🐞➽ ${prefix}cum
╠🐞➽ ${prefix}ero
╠🐞➽ ${prefix}kasedaiki
╠🐞➽ ${prefix}femdom
╠🐞➽ ${prefix}foot
╠🐞➽ ${prefix}gangbang
╠🐞➽ ${prefix}glasses
╠🐞➽ ${prefix}jahy
╠🐞➽ ${prefix}manga
╠🐞➽ ${prefix}masturbation
╠🐞➽ ${prefix}neko
╠🐞➽ ${prefix}orgy
╠🐞➽ ${prefix}panties
╠🐞➽ ${prefix}pussy
╠🐞➽ ${prefix}neko2
╠🐞➽ ${prefix}tentacles
╠🐞➽ ${prefix}thighs
╠🐞➽ ${prefix}yuri
╠🐞➽ ${prefix}zettai
║
╚════• 〘${nomeBot}〙•═════╝
`
}

function wallpaper(prefix, nomeBot, pushname) {

    return `
    ╭─⊣〘 ${nomeBot} 〙
    ║
    ╠🐞➽𝐔𝐙𝐔𝐀𝐑𝐈𝐎: ${pushname}
    ╠🐞➽𝐕𝐄𝐑𝐒Ã𝐎: 1.0.0
    ╠🐞➽𝐍𝐎𝐌𝐄:${pushname}
    ║
    ║╭─⊣〘 MENUS 〙
    ║
    ╠🐞➽${prefix}wallpaper1
    ╠🐞➽${prefix}wallpaper2
    ╠🐞➽${prefix}wallpaper3
    ╠🐞➽${prefix}wallpaper4
    ╠🐞➽${prefix}wallpaper5
    ╠🐞➽${prefix}wallpaper6
    ╠🐞➽${prefix}wallpaper7
    ╠🐞➽${prefix}wallpaper8
    ╠🐞➽${prefix}wallpaper9
    ║
    ╚════• 〘${nomeBot}〙•═════╝
    `
    }


module.exports = {
menu,
menuanime,
menuadm,
menudono,
wallpaper
}
