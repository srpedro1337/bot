40 path=arquivos/funções/mediafire.js
